<?php
/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.24.0-edef018 modeling language!*/

class TimeBlock
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //TimeBlock Attributes
  private $startTime;
  private $endTime;
  private $dayOfWeek;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public function __construct($aStartTime, $aEndTime, $aDayOfWeek)
  {
    $this->startTime = $aStartTime;
    $this->endTime = $aEndTime;
    $this->dayOfWeek = $aDayOfWeek;
  }

  //------------------------
  // INTERFACE
  //------------------------

  public function setStartTime($aStartTime)
  {
    $wasSet = false;
    $this->startTime = $aStartTime;
    $wasSet = true;
    return $wasSet;
  }

  public function setEndTime($aEndTime)
  {
    $wasSet = false;
    $this->endTime = $aEndTime;
    $wasSet = true;
    return $wasSet;
  }

  public function setDayOfWeek($aDayOfWeek)
  {
    $wasSet = false;
    $this->dayOfWeek = $aDayOfWeek;
    $wasSet = true;
    return $wasSet;
  }

  public function getStartTime()
  {
    return $this->startTime;
  }

  public function getEndTime()
  {
    return $this->endTime;
  }

  public function getDayOfWeek()
  {
    return $this->dayOfWeek;
  }

  public function equals($compareTo)
  {
    return $this == $compareTo;
  }

  public function delete()
  {}

}
?>